import {Component, Inject, OnInit, ViewEncapsulation} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';

@Component({
  selector: 'app-calling',
  templateUrl: './calling.component.html',
  styleUrls: ['./calling.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CallingComponent implements OnInit {

  constructor(private dialogRef: MatDialogRef<any>, @Inject(MAT_DIALOG_DATA) public data) { }

  ngOnInit(): void {
  }

  cancel(): void {
    this.dialogRef.close(false);
  }

  answer(): void {
    this.dialogRef.close(true);
  }

}
