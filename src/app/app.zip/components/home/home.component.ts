import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/services/auth.service';
import { DataService } from 'src/app/services/data.service';
import { TimerService } from 'src/app/services/timer.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  youCanLoadUnity = false

  constructor(
    private auth: AuthService,
    private data: DataService,
    public timerService: TimerService,
    private router: Router
  ) { }

  ngOnInit(): void {
    // this.auth.deleteUserInfo()

    this.data.visitableState.subscribe(state => {
      // if (state && state == -1) {
      //   console.log('state -1', state);
      //   this.auth.deleteUserInfo()
      //   this.router.navigate(['/index']);
      // } else if (state == 1) {
        console.log('this.auth.getUserId()', this.auth.getUserId());
        if (!this.auth.getUserId()) {
          this.router.navigate(['/index']);
        }
        this.youCanLoadUnity = true
      // } else {
      //   this.youCanLoadUnity = true
      //   console.log('this.youCanLoadUnity', this.youCanLoadUnity);
      // }
    });

  }

}
