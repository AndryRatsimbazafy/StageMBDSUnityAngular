import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conference-redif',
  templateUrl: './conference-redif.component.html',
  styleUrls: ['./conference-redif.component.css']
})
export class ConferenceRedifComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
